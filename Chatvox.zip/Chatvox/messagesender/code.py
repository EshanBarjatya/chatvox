from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
import requests
 # Setup the Google Sheets API
SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
SERVICE_ACCOUNT_FILE = 'messagesender/google sheets api.json'

credentials = Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# Call the Sheets API
service = build('sheets', 'v4', credentials=credentials)
sheet = service.spreadsheets()

# Read the sheet data
SPREADSHEET_ID = '1T1w8fquBWpsL4DKuMKJdMWkkTa1lOFVAH7hKTRKiUJM'
RANGE_NAME = 'Sheet1!A:E'  # Adjusted to include all columns you need
result = sheet.values().get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME).execute()
values = result.get('values', [])

access_token = "EAAFkxnZBSXb8BO640pEpZAEaa6kYRXSp1gztBxkiUpDK7WHIB6fhy7v4NDxD3Xhcb8uhM15pBZCM9Y6vln4PTbtgRr7C6dvUL2QQg1ATfc5PDRDxdVKClfLGxV9wTHTfhvlUlmyYe06WEdrQWqHZAi1mEW8Bmv2KtWu7Qp0LXZADurcdlwMRwbWyEecDvZAhIAFLoMKVDNn9mdc0zqqQZDZD"
url = "https://graph.facebook.com/v18.0/214379408423824/messages"

headers = {
    'Authorization': f'Bearer EAAFkxnZBSXb8BO640pEpZAEaa6kYRXSp1gztBxkiUpDK7WHIB6fhy7v4NDxD3Xhcb8uhM15pBZCM9Y6vln4PTbtgRr7C6dvUL2QQg1ATfc5PDRDxdVKClfLGxV9wTHTfhvlUlmyYe06WEdrQWqHZAi1mEW8Bmv2KtWu7Qp0LXZADurcdlwMRwbWyEecDvZAhIAFLoMKVDNn9mdc0zqqQZDZD',
    'Content-Type': 'application/json'
}
print(headers)
header_media_id = "media_id"  # Uncomment this if you're using a media ID
button_text = "this is a btn ifyyk"
# button_url = "https://anitajainfashions.com/" 


# Assuming phone numbers are in the second column (index 1)
phonenumbers = [row[1] for row in values if len(row) >= 5]
print(phonenumbers)





            # Send the message

        
        # return phone_number


def send_mark2_template(customer_info):
    # Gather inputs once before the loop
    template_name = "imagesender"
    header_image_url = input("Enter the URL of the image: ")  # Or use header_media_id if you have one
    temptext = input("Enter The Text Message You Want To Send: ")
    websiteurl = input(str("enter the url of the website something like: /products/chocolate-plain-crep : "))

    for row in values:
        if len(row) >= 2:  # Check if there are at least two columns
            phone_number1 = row[0]  # First phone number
            phone_number2 = row[1]  # Second phone number


            # The data payload for the request
            data = {
"messaging_product": "whatsapp",
"to": phone_number2,
"type": "template",
"template": {
    "name": "imagesender",
    "language": {
    "code": "en_US"
    },
"components": [
    {
        "type": "header",
        "parameters": [
            {
                "type": "image",
                "image": {
                    "link": header_image_url
                }
            }
        ]
    },
    {
        "type": "body",
        "parameters": [
            {
                "type": "text",
                "text": temptext
            }
        ]
    },
    {
        "type": "button",
        "sub_type": "url",
        "index": 0,
        "parameters": [
            {
                "type": "text",
                "text": websiteurl  
            }
        ]
    }
]
}
}
            # Send the POST request
            response = requests.post(url, headers=headers, json=data)

            # Check the response from WhatsApp
            if response.status_code == 200:
                print(f"Message sent to {phone_number1} ({phone_number2}) successfully with {template_name}.")
            else:
                print(f"Failed to send message to {phone_number1} ({phone_number2}). Status code: {response.status_code}, Response: {response.text}")
        else:
            print(f"Skipping row with insufficient data: {row}")


def send_mark3_template(customer_info):
    # Gather inputs once before the loop
    template_name = "mark4"
    header_video_url = input("Enter the URL of the video: ")  # Or use header_media_id if you have one
    websiteurl = input(str("enter the url of the website something like: /products/chocolate-plain-crep : "))
    temptext = input("Enter The Text Message You Want To Send: ")
    # temptext = "temp text"
                                        # "link": header_video_url  # Ensure this is a direct link to an image file
    

    for row in values:
        if len(row) >= 2:  # Check if there are at least two columns
            phone_number1 = row[0]  # First phone number
            phone_number2 = row[1]  # Second phone number

            # The data payload for the request
            data = {
                "messaging_product": "whatsapp",
                "to": phone_number2,
                "type": "template",
                "template": {
                    "name": "mark4",
                    "language": {
                        "code": "en_US"
                    },
                    "components": [
                        {
                            "type": "header",
                            "parameters": [
                                {
                                    "type": "video",
                                    "video": {
                                        "link": header_video_url  # Ensure this is a direct link to an video file
                                    }
                                }
                            ]
                        },
                        {
                            "type": "body",
                            "parameters": [
                                {
                                    "type": "text",
                                    "text": temptext   # The first placeholder value
                                },
                            ]
                        },
                        {
                            "type": "button",
                            "sub_type": "url",
                            "index": 0,
                            "parameters": [
                                {
                                    "type": "text",
                                    "text": websiteurl  
                                }
                            ]
                                    }
                        # Include any other components that your template might have, like buttons
                    ]
                }
            }

            # Send the POST request
            try:
                response = requests.post(url, headers=headers, json=data)
                response.raise_for_status()  # This will raise an exception for HTTP errors
                print(f"Message sent to {phone_number1} ({phone_number2}) successfully with video sender.")
            except requests.exceptions.HTTPError as err:
                print(f"HTTP error occurred: {err}")  # Python 3.6
                print(f"Response text: {response.text}")
            except Exception as err:
                print(f"An error occurred: {err}")

        else:
            print(f"Skipping row with insufficient data: {row}")


def sendtrackingmessage():
    for row in values:

        if len(row) >= 5:  # Ensure there are at least five columns with data
            customer_name = row[0]  # Customer's name from column A
            phone_number = row[1]   # Phone number from column B
            company_name = row[2]   # Company name from column C
            tracking_number = row[3]  # Tracking number from column D
            website = row[4]  # Website from column E

            # Construct the data payload for the API request
            data = {
            "messaging_product": "whatsapp",
            "to": phone_number,
            "type": "template",
            "template": {
                "name": "placeholder",  # Use the actual template name you set on WhatsApp Manager
                "language": {
                    "code": "en_US"
                },
                "components": [{
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": customer_name},
                        {"type": "text", "text": company_name},
                        {"type": "text", "text": tracking_number},
                        {"type": "text", "text": website}
                    ]
                }]
            }
        }
            response = requests.post(url, headers=headers, json=data)
            if response.status_code == 200:
                print(f"Message sent to {customer_name} ({phone_number}) successfully.")
            else:
                print(f"Failed to send message to {customer_name} ({phone_number}). Response: {response.text}")
        else:
            print(f"Skipping row with insufficient data: {row}")
