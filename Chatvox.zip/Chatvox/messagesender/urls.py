from django.contrib import admin
from django.urls import path,include
from .views import *
urlpatterns = [
    # path('', home),
    path('message-sender/', messagesender),
    path('template-message-sender/', template_message_sender),
    path('video-message-sender/', send_video_message),
    path('videomessagesenderroute/', videomessagesenderroute),
    path('iamge-message-sender/', send_image_message),
    path('imagemessagesenderroute/', imagemessagesenderroute),


    
]
