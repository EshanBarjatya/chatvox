from django.http import HttpResponse
import datetime
from django.shortcuts import render

def home(request):
    return render(request, "chatvox/index.html")